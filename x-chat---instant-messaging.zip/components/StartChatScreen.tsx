
import React, { useState } from 'react';
import { User } from '../types';
import { supabase } from '../lib/supabase';
import { SearchIllustration } from './Illustrations';

interface StartChatScreenProps {
  onBack: () => void;
  onSelectUser: (user: User) => void;
}

const StartChatScreen: React.FC<StartChatScreenProps> = ({ onBack, onSelectUser }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<User | null>(null);
  const [error, setError] = useState<string | null>(null);

  const isUUID = (str: string) => {
    const regex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return regex.test(str);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim();
    if (!query) return;

    setIsSearching(true);
    setError(null);
    setSearchResult(null);

    try {
      if (query.toLowerCase() === 'ai' || query.toLowerCase() === 'gemini') {
        onSelectUser({ id: 'ai', name: 'X-AI Assistant', username: 'ai', email: 'ai@xchat.com', is_online: true });
        return;
      }

      const { data, error: searchError } = await supabase
        .from('profiles')
        .select('*')
        .or(`username.eq."${query}",email.eq."${query}"`)
        .maybeSingle();

      if (searchError) {
        console.error("Search error:", searchError);
        setError("Error during search. Connection failed.");
      } else if (data) {
        setSearchResult({
          id: data.id,
          name: data.full_name || data.username,
          username: data.username,
          email: data.email || '',
          is_online: data.is_online
        });
      } else {
        if (isUUID(query)) {
            setSearchResult({ id: query, name: `User ${query.slice(0,4)}`, username: 'anon', email: '' });
        } else {
            setError("User not found. Try exact username or email.");
        }
      }
    } catch (err: any) {
      setError("An unexpected error occurred.");
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-white max-w-md mx-auto shadow-2xl relative overflow-hidden font-sans">
      <header className="p-5 flex items-center gap-4 bg-white sticky top-0 z-10">
        <button onClick={onBack} className="p-2 hover:bg-slate-50 rounded-2xl text-slate-500 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        </button>
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">Search Friends</h2>
      </header>

      <main className="flex-1 p-6 overflow-y-auto bg-slate-50/30">
        <SearchIllustration />
        
        <p className="text-slate-600 text-sm text-center mb-8 px-4 leading-relaxed">
          Search for anyone on <span className="font-bold text-teal-700">X-Chat</span> using their unique <span className="font-bold text-teal-700">username</span> or registered <span className="font-bold text-teal-700">email address</span>.
        </p>

        <form onSubmit={handleSearch} className="space-y-4">
          <div className="relative group">
            <div className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-teal-600 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            </div>
            <input 
              type="text"
              placeholder="Enter username or email"
              className="w-full bg-white border-2 border-slate-100 focus:border-teal-400 rounded-3xl py-4.5 pl-14 pr-6 text-black outline-none transition-all shadow-sm aqua-glow placeholder:text-slate-400"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <button 
            type="submit"
            disabled={isSearching}
            className="w-full teal-gradient text-slate-900 font-bold py-4.5 rounded-[1.5rem] shadow-xl shadow-teal-100/50 active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSearching ? (
              <>
                <div className="w-5 h-5 border-3 border-slate-900/30 border-t-slate-900 rounded-full animate-spin"></div>
                Searching...
              </>
            ) : 'Search People'}
          </button>
        </form>

        <div className="mt-10">
          {error && (
            <div className="p-5 bg-orange-50 border border-orange-100 rounded-3xl animate-[fadeIn_0.3s_ease-out]">
              <p className="text-orange-900 text-xs font-bold uppercase tracking-widest mb-1">No Results</p>
              <p className="text-orange-800 text-sm leading-relaxed">{error}</p>
            </div>
          )}
          
          {searchResult && (
            <div className="animate-[slideUp_0.3s_ease-out]">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Matches Found</h3>
              <button 
                onClick={() => onSelectUser(searchResult)}
                className="w-full flex items-center gap-4 p-5 rounded-[2rem] bg-white border border-teal-100/50 hover:border-teal-200 hover:shadow-lg shadow-teal-100/20 transition-all group"
              >
                <div className="relative">
                    <div className="w-16 h-16 rounded-[1.5rem] bg-teal-500 flex items-center justify-center text-slate-900 font-bold text-2xl group-hover:scale-110 transition-transform shadow-md">
                        {searchResult.name.charAt(0)}
                    </div>
                    {searchResult.is_online && <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-4 border-white"></div>}
                </div>
                <div className="text-left overflow-hidden">
                  <h4 className="font-bold text-slate-800 text-lg leading-tight truncate">{searchResult.name}</h4>
                  <p className="text-sm text-slate-500">@{searchResult.username}</p>
                </div>
                <div className="ml-auto text-teal-600 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all">
                   <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
                </div>
              </button>
            </div>
          )}
        </div>

        <div className="mt-14 pb-8">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Official Channels</h3>
          <div className="flex gap-4">
            <button 
              onClick={() => onSelectUser({ id: 'ai', name: 'X-AI Assistant', username: 'ai', email: 'ai@xchat.com', is_online: true })} 
              className="flex flex-col items-center gap-3 group"
            >
              <div className="w-16 h-16 rounded-[1.5rem] teal-gradient flex items-center justify-center text-slate-900 font-bold shadow-xl shadow-teal-100 group-hover:scale-105 group-active:scale-95 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2Zm0 16a6 6 0 1 1 6-6 6 6 0 0 1-6 6Z"/><circle cx="12" cy="12" r="2"/></svg>
              </div>
              <span className="text-[11px] font-bold text-slate-600 group-hover:text-teal-700 transition-colors">X-AI Assistant</span>
            </button>
          </div>
        </div>
      </main>

      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
};

export default StartChatScreen;
