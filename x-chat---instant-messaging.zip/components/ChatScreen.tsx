
import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage } from '../types';
import { chatWithAI } from '../services/geminiService';

interface ChatScreenProps {
  user: User;
  onLogout: () => void;
}

const ChatScreen: React.FC<ChatScreenProps> = ({ user, onLogout }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    // Fix: Updated to match ChatMessage interface (sender_id, receiver_id, content, created_at, is_read)
    { 
      id: '1', 
      sender_id: 'ai', 
      receiver_id: user.id,
      content: `Hi ${user.name}! Welcome to TealTalk ✨ How can I help you today?`, 
      created_at: new Date().toISOString(),
      is_read: true
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    // Fix: Updated to match ChatMessage interface
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      sender_id: user.id,
      receiver_id: 'ai',
      content: inputValue,
      created_at: new Date().toISOString(),
      is_read: false
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    const aiResponse = await chatWithAI(inputValue);
    
    // Fix: Updated to match ChatMessage interface
    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      sender_id: 'ai',
      receiver_id: user.id,
      content: aiResponse || "Error getting response.",
      created_at: new Date().toISOString(),
      is_read: true
    };

    setIsTyping(false);
    setMessages(prev => [...prev, aiMessage]);
  };

  return (
    <div className="flex flex-col h-screen bg-white max-w-4xl mx-auto shadow-2xl">
      {/* Header */}
      <header className="p-4 border-b border-teal-50 flex items-center justify-between bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full teal-gradient flex items-center justify-center text-white font-bold">
            {user.name.charAt(0)}
          </div>
          <div>
            <h2 className="font-bold text-slate-800 leading-tight">TealTalk</h2>
            <p className="text-xs text-teal-500 font-medium flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-teal-500 animate-pulse"></span>
              Online
            </p>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="text-slate-400 hover:text-red-500 transition-colors p-2 rounded-full hover:bg-red-50"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
        </button>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            // Fix: Updated property access to msg.sender_id to match type definition
            className={`flex ${msg.sender_id === user.id ? 'justify-end' : 'justify-start'} animate-[fadeIn_0.3s_ease-out]`}
          >
            <div className={`max-w-[80%] rounded-2xl p-4 shadow-sm ${
              // Fix: Updated property access to msg.sender_id
              msg.sender_id === user.id 
                ? 'bg-teal-500 text-white rounded-tr-none' 
                : 'bg-slate-100 text-slate-800 rounded-tl-none'
            }`}>
              {/* Fix: Updated property access to msg.content */}
              <p className="text-sm leading-relaxed">{msg.content}</p>
              {/* Fix: Updated property access to msg.sender_id and msg.created_at */}
              <p className={`text-[10px] mt-1 text-right ${msg.sender_id === user.id ? 'text-teal-100' : 'text-slate-400'}`}>
                {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-slate-100 rounded-2xl p-4 rounded-tl-none shadow-sm flex gap-1">
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-teal-50 bg-slate-50/50">
        <form onSubmit={handleSendMessage} className="relative flex items-center gap-3">
          <input 
            type="text"
            className="w-full bg-white border border-teal-100/50 rounded-full px-6 py-4 pr-16 text-sm text-slate-800 aqua-glow transition-all"
            placeholder="Type your message..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />
          <button 
            type="submit"
            className="absolute right-2 teal-gradient text-white p-3 rounded-full shadow-lg shadow-teal-200/50 active:scale-95 transition-transform"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polyline points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </form>
      </div>
      
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default ChatScreen;
