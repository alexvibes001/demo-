
import React, { useState } from 'react';
import { SignUpIllustration } from './Illustrations';
import { supabase } from '../lib/supabase';

interface SignUpScreenProps {
  onNavigate: () => void;
  onSuccess: () => void;
}

const SignUpScreen: React.FC<SignUpScreenProps> = ({ onNavigate, onSuccess }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    fullName: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            full_name: formData.fullName,
            username: formData.username,
          }
        }
      });

      if (authError) {
        setError(authError.message);
        setIsLoading(false);
        return;
      }

      // Try to create a profile in the public 'profiles' table
      if (authData.user) {
        const { error: profileError } = await supabase
          .from('profiles')
          .insert([{
            id: authData.user.id,
            username: formData.username,
            full_name: formData.fullName,
            email: formData.email
          }]);
        
        if (profileError) {
          console.warn("Profile creation failed (table might be missing):", profileError.message);
        }
      }

      onSuccess();
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 page-transition">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-xl shadow-teal-100/50 p-8 md:p-12 border border-teal-50/50 overflow-hidden">
        <SignUpIllustration />
        
        <div className="text-center mb-8">
          <h1 className="text-3xl font-black text-slate-900 mb-2 tracking-tighter uppercase">X-CHAT</h1>
          <p className="text-slate-500">Join the next generation of instant messaging.</p>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-100 text-red-600 text-sm rounded-2xl">
            {error}
          </div>
        )}

        <form onSubmit={handleSignUp} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 ml-2 uppercase tracking-wider">Full Name</label>
              <input 
                type="text" 
                required 
                placeholder="Jane Doe"
                className="w-full bg-slate-50 border-0 rounded-2xl px-4 py-3 text-sm text-black aqua-glow transition-all placeholder:text-slate-400"
                value={formData.fullName}
                onChange={e => setFormData({...formData, fullName: e.target.value})}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700 ml-2 uppercase tracking-wider">Username</label>
              <input 
                type="text" 
                required 
                placeholder="janedoe"
                className="w-full bg-slate-50 border-0 rounded-2xl px-4 py-3 text-sm text-black aqua-glow transition-all placeholder:text-slate-400"
                value={formData.username}
                onChange={e => setFormData({...formData, username: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 ml-2 uppercase tracking-wider">Email Address</label>
            <input 
              type="email" 
              required 
              placeholder="jane@example.com"
              className="w-full bg-slate-50 border-0 rounded-2xl px-4 py-3 text-sm text-black aqua-glow transition-all placeholder:text-slate-400"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 ml-2 uppercase tracking-wider">Password</label>
            <input 
              type="password" 
              required 
              placeholder="••••••••"
              className="w-full bg-slate-50 border-0 rounded-2xl px-4 py-3 text-sm text-black aqua-glow transition-all placeholder:text-slate-400"
              value={formData.password}
              onChange={e => setFormData({...formData, password: e.target.value})}
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 ml-2 uppercase tracking-wider">Confirm Password</label>
            <input 
              type="password" 
              required 
              placeholder="••••••••"
              className="w-full bg-slate-50 border-0 rounded-2xl px-4 py-3 text-sm text-black aqua-glow transition-all placeholder:text-slate-400"
              value={formData.confirmPassword}
              onChange={e => setFormData({...formData, confirmPassword: e.target.value})}
            />
          </div>

          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full teal-gradient text-slate-900 font-bold py-4 rounded-full shadow-lg shadow-teal-200/50 hover:shadow-teal-300/60 transition-all active:scale-[0.98] disabled:opacity-70 mt-4"
          >
            {isLoading ? "Initializing..." : "Join X-Chat"}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-slate-500 text-sm">
            Already have an account?{' '}
            <button onClick={onNavigate} className="font-semibold text-teal-700 hover:underline">Log in</button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default SignUpScreen;
