
import React, { useState, useEffect, useMemo } from 'react';
import { User, Conversation } from '../types';
import { supabase } from '../lib/supabase';
import { EmptyChatsIllustration } from './Illustrations';

interface ChatDashboardProps {
  user: User;
  onStartNewChat: () => void;
  onSelectConversation: (partner: User) => void;
  onLogout: () => void;
}

const ChatDashboard: React.FC<ChatDashboardProps> = ({ user, onStartNewChat, onSelectConversation, onLogout }) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [dbError, setDbError] = useState<string | null>(null);

  // Fast fetch function
  const fetchConversations = async (silent = false) => {
    if (!silent) setLoading(true);
    setDbError(null);
    
    try {
      const { data, error } = await supabase
        .from('messages')
        .select(`content, created_at, sender_id, receiver_id, is_read`)
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (error) {
        console.error("Dashboard Fetch Error:", error.message);
        setDbError(error.message);
      } else if (data) {
        const partnersMap = new Map<string, Conversation>();
        
        // Always add AI Assistant
        partnersMap.set('ai', {
          partner: { id: 'ai', name: 'X-AI Assistant', username: 'ai', email: 'ai@xchat.com', is_online: true },
          lastMessage: 'Tap to chat with your AI assistant ✨',
          lastTimestamp: '',
          unreadCount: 0
        });

        data.forEach(msg => {
          const partnerId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
          if (partnerId === user.id || partnerId === 'ai') return;
          
          const isUnread = !msg.is_read && msg.receiver_id === user.id;
          const existing = partnersMap.get(partnerId);

          if (!existing) {
            partnersMap.set(partnerId, {
              partner: { 
                id: partnerId, 
                name: `User ${partnerId.slice(0, 4)}`, 
                username: `user_${partnerId.slice(0, 4)}`, 
                email: '',
                is_online: false 
              },
              lastMessage: msg.content,
              lastTimestamp: formatTime(msg.created_at),
              unreadCount: isUnread ? 1 : 0
            });
          } else if (isUnread) {
            existing.unreadCount = (existing.unreadCount || 0) + 1;
          }
        });

        setConversations(Array.from(partnersMap.values()));
      }
    } catch (err: any) {
      setDbError(err.message || "Connection failed");
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const formatTime = (iso: string) => {
    const date = new Date(iso);
    const now = new Date();
    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  useEffect(() => {
    fetchConversations();

    // Specific Realtime subscription for list updates
    const channel = supabase.channel(`dashboard_${user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => {
        fetchConversations(true); // Silent refresh
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user.id]);

  return (
    <div className="flex flex-col h-screen bg-white max-w-md mx-auto shadow-2xl relative overflow-hidden animate-in fade-in duration-300">
      <header className="p-5 pt-8 pb-4 teal-gradient flex items-center justify-between sticky top-0 z-20 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-white/30 backdrop-blur-md flex items-center justify-center text-slate-900 font-black text-xl border border-white/40 shadow-sm">
            X
          </div>
          <div>
            <h1 className="font-bold text-slate-900 text-xl tracking-tight leading-none">X-Chat</h1>
            <p className="text-[9px] text-teal-950 font-bold uppercase tracking-[0.2em] opacity-80 mt-1">Instant Speed</p>
          </div>
        </div>
        <button onClick={onLogout} className="text-slate-900 hover:text-black transition-all p-2 rounded-xl active:scale-90">
          <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
        </button>
      </header>

      <main className="flex-1 overflow-y-auto bg-slate-50/30 custom-scrollbar">
        <div className="p-4 space-y-1">
          {dbError && !loading && (
            <div className="mx-4 p-4 bg-orange-50 border border-orange-100 rounded-2xl mb-4 text-[10px] text-orange-700 font-bold flex gap-2 items-center">
              <span>⚠️ Sync Issue: Tables not found or connection low.</span>
            </div>
          )}

          <h3 className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.25em] mb-3 mt-4">Messages</h3>
          
          {loading ? (
            <div className="px-4 space-y-4">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="flex gap-4 items-center p-3">
                  <div className="w-14 h-14 rounded-2xl skeleton shrink-0"></div>
                  <div className="flex-1 space-y-3">
                    <div className="h-3 w-1/3 skeleton rounded-full"></div>
                    <div className="h-2 w-2/3 skeleton rounded-full"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-1">
              {conversations.map((chat, idx) => (
                <button
                  key={idx}
                  onClick={() => onSelectConversation(chat.partner)}
                  className="w-full flex items-center gap-4 p-4 rounded-[1.75rem] hover:bg-white transition-all active:scale-[0.98] border border-transparent hover:border-teal-50/50 group hover:shadow-sm"
                >
                  <div className="relative shrink-0">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-slate-900 font-bold text-xl transition-all group-hover:scale-105 ${chat.partner.id === 'ai' ? 'teal-gradient' : 'bg-slate-200 text-slate-500'}`}>
                      {chat.partner.name.charAt(0)}
                    </div>
                    {chat.partner.is_online && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-[3px] border-white rounded-full"></div>
                    )}
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="font-bold text-slate-800 tracking-tight truncate">{chat.partner.name}</span>
                      <span className="text-[9px] text-slate-400 font-bold ml-2 whitespace-nowrap">{chat.lastTimestamp}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-slate-500 truncate pr-4">{chat.lastMessage}</p>
                      {(chat.unreadCount || 0) > 0 && (
                        <div className="bg-teal-500 text-slate-900 text-[9px] font-black h-5 min-w-[20px] px-1.5 flex items-center justify-center rounded-full shadow-lg shadow-teal-100">
                          {chat.unreadCount}
                        </div>
                      )}
                    </div>
                  </div>
                </button>
              ))}

              {conversations.length <= 1 && (
                <div className="flex flex-col items-center justify-center py-24 text-center px-10">
                  <EmptyChatsIllustration />
                  <h4 className="text-slate-800 font-bold mt-6 text-lg">Empty Inbox</h4>
                  <p className="text-slate-400 text-xs mt-2 leading-relaxed max-w-[200px] mx-auto">Your X-Chat messages will appear here. Start a chat to begin!</p>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      <button
        onClick={onStartNewChat}
        className="absolute bottom-8 right-6 w-16 h-16 teal-gradient rounded-2xl shadow-xl shadow-teal-200/50 flex items-center justify-center text-slate-900 transform hover:scale-110 active:scale-95 transition-all z-20 border-4 border-white"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
    </div>
  );
};

export default ChatDashboard;
