
import React from 'react';

export const LoginIllustration: React.FC = () => (
  <div className="relative w-48 h-48 mx-auto mb-8 animate-float">
    <svg viewBox="0 0 200 200" className="w-full h-full">
      <rect x="65" y="40" width="70" height="120" rx="12" fill="#E2E8F0" />
      <rect x="70" y="50" width="60" height="100" rx="6" fill="#FFFFFF" />
      <circle cx="100" cy="155" r="4" fill="#CBD5E0" />
      <path d="M40 80 Q40 60 65 60 L95 60 Q120 60 120 80 L120 100 Q120 120 95 120 L55 120 L30 145 L40 115 Z" fill="#4FD1C5" fillOpacity="0.9" />
      <path d="M165 110 Q165 95 145 95 L115 95 Q95 95 95 110 L95 125 Q95 140 115 140 L145 140 L170 160 L165 130 Z" fill="#81E6D9" fillOpacity="0.7" />
    </svg>
  </div>
);

export const SignUpIllustration: React.FC = () => (
  <div className="relative w-48 h-48 mx-auto mb-6 animate-float">
    <svg viewBox="0 0 200 200" className="w-full h-full">
      <circle cx="100" cy="80" r="35" fill="#4FD1C5" fillOpacity="0.15" />
      <path d="M50 170 Q100 120 150 170" stroke="#4FD1C5" strokeWidth="10" fill="none" strokeLinecap="round" />
      <rect x="85" y="95" width="30" height="55" rx="5" fill="#38B2AC" />
      <circle cx="45" cy="55" r="18" fill="#81E6D9" fillOpacity="0.85" />
      <circle cx="155" cy="75" r="22" fill="#4FD1C5" fillOpacity="0.7" />
      <circle cx="145" cy="35" r="12" fill="#B2F5EA" />
    </svg>
  </div>
);

export const EmptyChatsIllustration: React.FC = () => (
  <div className="w-40 h-40 mx-auto opacity-60">
    <svg viewBox="0 0 200 200" className="w-full h-full">
      <circle cx="100" cy="100" r="80" fill="#F1F5F9" />
      <path d="M70 70 Q70 55 85 55 L115 55 Q130 55 130 70 L130 90 Q130 105 115 105 L85 105 L60 125 L70 95 Z" fill="#94A3B8" />
      <path d="M110 110 Q110 100 120 100 L140 100 Q150 100 150 110 L150 120 Q150 130 140 130 L120 130 L105 145 L110 125 Z" fill="#CBD5E0" />
    </svg>
  </div>
);

export const SearchIllustration: React.FC = () => (
  <div className="w-48 h-48 mx-auto mb-4">
    <svg viewBox="0 0 200 200" className="w-full h-full">
      <circle cx="80" cy="80" r="40" stroke="#4FD1C5" strokeWidth="6" fill="none" />
      <line x1="110" y1="110" x2="150" y2="150" stroke="#4FD1C5" strokeWidth="10" strokeLinecap="round" />
      <rect x="120" y="40" width="40" height="50" rx="4" fill="#B2F5EA" fillOpacity="0.5" />
      <rect x="40" y="130" width="50" height="40" rx="4" fill="#B2F5EA" fillOpacity="0.5" />
    </svg>
  </div>
);
