
import React, { useState } from 'react';
import { LoginIllustration } from './Illustrations';
import { supabase } from '../lib/supabase';

interface LoginScreenProps {
  onNavigate: () => void;
  onSuccess: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onNavigate, onSuccess }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({ email: '', password: '' });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const { error: authError } = await supabase.auth.signInWithPassword({
      email: formData.email,
      password: formData.password,
    });

    if (authError) {
      setError(authError.message);
      setIsLoading(false);
    } else {
      onSuccess();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50/50 page-transition font-sans">
      <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl shadow-teal-100/40 p-10 md:p-14 border border-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-teal-50 rounded-full -mr-16 -mt-16 opacity-40"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-teal-50 rounded-full -ml-12 -mb-12 opacity-30"></div>
        
        <LoginIllustration />
        
        <div className="text-center mb-10 relative">
          <h1 className="text-3xl font-black text-slate-900 mb-2 tracking-tighter">X-CHAT</h1>
          <p className="text-slate-500 text-sm leading-relaxed">Securely sign in to your instant messaging dashboard.</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-100 text-red-600 text-[11px] font-bold uppercase tracking-wider rounded-2xl animate-shake">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6 relative">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] ml-2">Email Address</label>
            <input 
              type="email"
              required
              className="w-full bg-slate-50/50 border-2 border-slate-50 rounded-2xl px-5 py-4 text-slate-900 placeholder-slate-400 aqua-glow transition-all duration-200 outline-none"
              placeholder="name@example.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>

          <div className="space-y-1.5 relative">
            <label className="text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] ml-2">Password</label>
            <div className="relative">
              <input 
                type={showPassword ? "text" : "password"}
                required
                className="w-full bg-slate-50/50 border-2 border-slate-50 rounded-2xl px-5 py-4 text-slate-900 placeholder-slate-400 aqua-glow transition-all duration-200 outline-none"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-teal-600 transition-colors p-1"
              >
                {showPassword ? (
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.52 13.52 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" x2="22" y1="2" y2="22"/></svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                )}
              </button>
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full teal-gradient text-slate-900 font-bold py-4.5 rounded-[1.75rem] shadow-xl shadow-teal-200/50 hover:shadow-teal-300/60 transition-all duration-300 active:scale-[0.98] disabled:opacity-70 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-3 border-slate-900/30 border-t-slate-900 rounded-full animate-spin"></div>
                Signing In...
              </>
            ) : "Sign In to X-Chat"}
          </button>
        </form>

        <div className="mt-10 text-center relative">
          <p className="text-slate-500 text-sm">
            New to X-Chat?{' '}
            <button onClick={onNavigate} className="font-bold text-teal-700 hover:text-teal-800 underline decoration-teal-100 decoration-2 underline-offset-4">Create account</button>
          </p>
        </div>
      </div>
      <style>{`
        @keyframes animate-shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        .animate-shake { animation: animate-shake 0.3s ease-in-out; }
      `}</style>
    </div>
  );
};

export default LoginScreen;
