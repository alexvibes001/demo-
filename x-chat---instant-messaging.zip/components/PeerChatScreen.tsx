
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { User, ChatMessage } from '../types';
import { chatWithAI } from '../services/geminiService';
import { supabase } from '../lib/supabase';

interface PeerChatScreenProps {
  currentUser: User;
  partner: User;
  onBack: () => void;
}

const PeerChatScreen: React.FC<PeerChatScreenProps> = ({ currentUser, partner, onBack }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false); // For AI responses
  const [isPartnerTyping, setIsPartnerTyping] = useState(false); // For real users
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<any>(null);
  const partnerTypingTimeoutRef = useRef<any>(null);

  const isAI = partner.id === 'ai';

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  }, []);

  // Fetch History
  useEffect(() => {
    const fetchHistory = async () => {
      if (isAI) {
        setMessages([{
          id: 'welcome-ai',
          sender_id: 'ai',
          receiver_id: currentUser.id,
          content: `Hi ${currentUser.name}! I'm X-AI, your instant assistant. How can I help you today? ✨`,
          created_at: new Date().toISOString(),
          is_read: true,
          status: 'read'
        }]);
        return;
      }

      // Bulk mark as read immediately
      supabase.from('messages').update({ is_read: true }).eq('receiver_id', currentUser.id).eq('sender_id', partner.id).then();

      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .or(`and(sender_id.eq.${currentUser.id},receiver_id.eq.${partner.id}),and(sender_id.eq.${partner.id},receiver_id.eq.${currentUser.id})`)
        .order('created_at', { ascending: true });

      if (data) setMessages(data as ChatMessage[]);
      scrollToBottom('auto');
    };

    fetchHistory();

    if (!isAI) {
      const channelId = `chat_${[currentUser.id, partner.id].sort().join('_')}`;
      const channel = supabase.channel(channelId)
        .on('postgres_changes', { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'messages',
          filter: `receiver_id=eq.${currentUser.id}`
        }, (payload) => {
          const newMessage = payload.new as ChatMessage;
          if (newMessage.sender_id === partner.id) {
            setMessages(prev => [...prev, newMessage]);
            supabase.from('messages').update({ is_read: true }).eq('id', newMessage.id).then();
            // Stop typing indicator when message received
            setIsPartnerTyping(false);
          }
        })
        .on('postgres_changes', { 
          event: 'UPDATE', 
          schema: 'public', 
          table: 'messages',
          filter: `sender_id=eq.${currentUser.id}`
        }, (payload) => {
          const updatedMsg = payload.new as ChatMessage;
          setMessages(prev => prev.map(m => m.id === updatedMsg.id ? updatedMsg : m));
        })
        .on('broadcast', { event: 'typing' }, (payload) => {
          if (payload.payload.user_id === partner.id) {
            setIsPartnerTyping(payload.payload.typing);
            
            // Safety timeout: if we don't get a "stopped typing" event, clear it after 5 seconds
            if (payload.payload.typing) {
              if (partnerTypingTimeoutRef.current) clearTimeout(partnerTypingTimeoutRef.current);
              partnerTypingTimeoutRef.current = setTimeout(() => {
                setIsPartnerTyping(false);
              }, 5000);
            }
          }
        })
        .subscribe();

      return () => { 
        supabase.removeChannel(channel); 
        if (partnerTypingTimeoutRef.current) clearTimeout(partnerTypingTimeoutRef.current);
      };
    }
  }, [partner.id, currentUser.id]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isPartnerTyping, isTyping, scrollToBottom]);

  const handleTyping = () => {
    if (isAI) return;
    const channelId = `chat_${[currentUser.id, partner.id].sort().join('_')}`;
    supabase.channel(channelId).send({
      type: 'broadcast',
      event: 'typing',
      payload: { user_id: currentUser.id, typing: true },
    });

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = window.setTimeout(() => {
      supabase.channel(channelId).send({
        type: 'broadcast',
        event: 'typing',
        payload: { user_id: currentUser.id, typing: false },
      });
    }, 2500);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const content = inputValue.trim();
    if (!content) return;

    setInputValue('');
    // Immediately tell partner we stopped typing
    if (!isAI) {
      const channelId = `chat_${[currentUser.id, partner.id].sort().join('_')}`;
      supabase.channel(channelId).send({
        type: 'broadcast',
        event: 'typing',
        payload: { user_id: currentUser.id, typing: false },
      });
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    }

    const tempId = `temp-${Date.now()}`;

    // OPTIMISTIC UI: Add message immediately
    const optimisticMsg: ChatMessage = {
      id: tempId,
      sender_id: currentUser.id,
      receiver_id: partner.id,
      content,
      created_at: new Date().toISOString(),
      is_read: false,
      status: 'sending'
    };
    
    setMessages(prev => [...prev, optimisticMsg]);

    if (isAI) {
      setIsTyping(true);
      const response = await chatWithAI(content);
      setIsTyping(false);
      setMessages(prev => [
        ...prev.filter(m => m.id !== tempId),
        { ...optimisticMsg, id: Date.now().toString(), status: 'sent' },
        {
          id: (Date.now() + 1).toString(),
          sender_id: 'ai',
          receiver_id: currentUser.id,
          content: response || "Brain stall... try again!",
          created_at: new Date().toISOString(),
          is_read: true,
          status: 'read'
        }
      ]);
    } else {
      try {
        const { data, error } = await supabase
          .from('messages')
          .insert([{ sender_id: currentUser.id, receiver_id: partner.id, content }])
          .select()
          .single();

        if (error) throw error;

        // Replace optimistic message with server message
        setMessages(prev => prev.map(m => m.id === tempId ? { ...data, status: 'sent' } : m));
      } catch (err) {
        setMessages(prev => prev.map(m => m.id === tempId ? { ...m, status: 'failed' } : m));
      }
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 max-w-md mx-auto shadow-2xl relative overflow-hidden font-sans">
      <header className="p-4 bg-white border-b border-teal-50 flex items-center gap-3 sticky top-0 z-20 shadow-sm">
        <button onClick={onBack} className="p-2 -ml-2 hover:bg-slate-50 rounded-xl text-slate-500 transition-all active:scale-90">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div className="relative">
          <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-slate-900 font-bold shadow-md ${isAI ? 'teal-gradient' : 'bg-slate-200 text-slate-500'}`}>
            {partner.name.charAt(0)}
          </div>
          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white bg-green-500"></div>
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-slate-800 text-sm leading-tight truncate">{partner.name}</h3>
          <p className={`text-[9px] font-bold uppercase tracking-wider ${isPartnerTyping ? 'text-teal-600 animate-pulse' : 'text-slate-500'}`}>
            {isPartnerTyping ? 'Typing...' : 'Active Now'}
          </p>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#f8fafc] custom-scrollbar">
        {messages.map((msg) => {
          const isMe = msg.sender_id === currentUser.id;
          return (
            <div key={msg.id} className={`flex items-end gap-2 ${isMe ? 'flex-row-reverse' : 'flex-row'} animate-in slide-in-from-bottom-2 duration-200`}>
              <div className={`max-w-[80%] p-3.5 rounded-2xl shadow-sm relative ${
                isMe ? 'bg-teal-500 text-slate-900 rounded-br-none' : 'bg-white text-slate-700 rounded-bl-none'
              } ${msg.status === 'failed' ? 'border-2 border-red-300' : ''}`}>
                <p className="text-[13px] font-medium leading-relaxed">{msg.content}</p>
                <div className="flex items-center justify-end gap-1.5 mt-1">
                  <span className={`text-[8px] font-bold uppercase ${isMe ? 'text-teal-900' : 'text-slate-400'}`}>
                    {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  {isMe && (
                    <div className="flex scale-75">
                      {msg.status === 'sending' ? (
                        <div className="w-2 h-2 border-2 border-teal-900 border-t-transparent rounded-full animate-spin"></div>
                      ) : msg.status === 'failed' ? (
                        <span className="text-red-700 font-bold">!</span>
                      ) : (
                        <>
                          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className={`${msg.is_read ? 'text-slate-900' : 'text-teal-800'} -mr-1`}><polyline points="20 6 9 17 4 12"/></svg>
                          {msg.is_read && <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" className="text-slate-900"><polyline points="20 6 9 17 4 12"/></svg>}
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        
        {/* Visual Typing Indicator for Partner or AI */}
        {(isTyping || isPartnerTyping) && (
          <div className="flex justify-start items-end gap-2 animate-in slide-in-from-bottom-2 duration-200">
            <div className="bg-white rounded-2xl p-3 shadow-sm rounded-bl-none flex gap-1">
              <div className="w-1.5 h-1.5 bg-teal-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
              <div className="w-1.5 h-1.5 bg-teal-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
              <div className="w-1.5 h-1.5 bg-teal-400 rounded-full animate-bounce"></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-3 bg-white border-t border-teal-50">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          <input 
            type="text"
            placeholder="Type a message..."
            className="flex-1 bg-slate-50 border border-transparent focus:bg-white focus:border-teal-100 rounded-2xl px-5 py-3 text-sm text-black outline-none transition-all placeholder:text-slate-400"
            value={inputValue}
            onChange={(e) => {
              setInputValue(e.target.value);
              handleTyping();
            }}
          />
          <button 
            type="submit"
            disabled={!inputValue.trim()}
            className={`p-3 rounded-2xl transition-all ${
              inputValue.trim() ? 'bg-teal-500 text-slate-900 shadow-lg shadow-teal-100 scale-100' : 'bg-slate-100 text-slate-300 scale-90'
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polyline points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </form>
      </div>
    </div>
  );
};

export default PeerChatScreen;
