
export type AuthScreen = 'LOGIN' | 'SIGN_UP' | 'CHAT_DASHBOARD' | 'START_CHAT' | 'PEER_CHAT';

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  avatar_url?: string;
  is_online?: boolean;
  last_seen?: string;
  status_text?: string;
}

export type MessageStatus = 'sending' | 'sent' | 'delivered' | 'read' | 'failed';

export interface ChatMessage {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
  is_read: boolean;
  status?: MessageStatus;
}

export interface Conversation {
  partner: User;
  lastMessage?: string;
  lastTimestamp?: string;
  unreadCount?: number;
}
