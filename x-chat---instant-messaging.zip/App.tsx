
import React, { useState, useEffect } from 'react';
import { AuthScreen, User } from './types';
import LoginScreen from './components/LoginScreen';
import SignUpScreen from './components/SignUpScreen';
import ChatDashboard from './components/ChatDashboard';
import StartChatScreen from './components/StartChatScreen';
import PeerChatScreen from './components/PeerChatScreen';
import { supabase } from './lib/supabase';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<AuthScreen>('LOGIN');
  const [user, setUser] = useState<User | null>(null);
  const [activePartner, setActivePartner] = useState<User | null>(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        const userData: User = {
          id: session.user.id,
          name: session.user.user_metadata?.full_name || 'User',
          username: session.user.user_metadata?.username || 'user',
          email: session.user.email || '',
        };
        setUser(userData);
        setCurrentScreen('CHAT_DASHBOARD');
      }
      setInitializing(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        const userData: User = {
          id: session.user.id,
          name: session.user.user_metadata?.full_name || 'User',
          username: session.user.user_metadata?.username || 'user',
          email: session.user.email || '',
        };
        setUser(userData);
        setCurrentScreen('CHAT_DASHBOARD');
      } else {
        setUser(null);
        setCurrentScreen('LOGIN');
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleStartChat = (partner: User) => {
    setActivePartner(partner);
    setCurrentScreen('PEER_CHAT');
  };

  if (initializing) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-12 h-12 border-4 border-teal-200 border-t-teal-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 overflow-x-hidden font-sans">
      {currentScreen === 'LOGIN' && (
        <LoginScreen 
          onNavigate={() => setCurrentScreen('SIGN_UP')} 
          onSuccess={() => setCurrentScreen('CHAT_DASHBOARD')} 
        />
      )}
      {currentScreen === 'SIGN_UP' && (
        <SignUpScreen 
          onNavigate={() => setCurrentScreen('LOGIN')} 
          onSuccess={() => setCurrentScreen('CHAT_DASHBOARD')} 
        />
      )}
      {currentScreen === 'CHAT_DASHBOARD' && user && (
        <ChatDashboard 
          user={user} 
          onStartNewChat={() => setCurrentScreen('START_CHAT')}
          onSelectConversation={handleStartChat}
          onLogout={async () => {
            await supabase.auth.signOut();
          }} 
        />
      )}
      {currentScreen === 'START_CHAT' && user && (
        <StartChatScreen 
          onBack={() => setCurrentScreen('CHAT_DASHBOARD')}
          onSelectUser={handleStartChat}
        />
      )}
      {currentScreen === 'PEER_CHAT' && user && activePartner && (
        <PeerChatScreen 
          currentUser={user}
          partner={activePartner}
          onBack={() => setCurrentScreen('CHAT_DASHBOARD')}
        />
      )}
    </div>
  );
};

export default App;
