
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://mtkfxlcqpwmgivsyysss.supabase.co';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY || 'sb_publishable_ZQR9-P-HaH91jcOZXh-jQg_ir_pq0X-';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
